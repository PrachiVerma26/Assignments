# To process and validate member data, we define the Member class and related functions.
from .utils import clean_name, validate_email, validate_phone

# The InvalidMemberDataError exception is raised when a member's data is invalid
class InvalidMemberDataError(Exception):
    pass

# To represent a member with name, email, and phone attributes
class Member:

    def __init__(self, name, email, phone):
        self.name = name
        self.email = email
        self.phone = phone

    def __str__(self):
        return f"{self.name} - {self.email} - {self.phone}"

# To process a single member's data and validate it
def process_member(data):
    name = clean_name(data["name"])
    email = data["email"].strip()
    phone = data["phone"].strip()

    if not validate_email(email):
        raise InvalidMemberDataError(f"Invalid email for member '{name}'")

    if not validate_phone(phone):
        raise InvalidMemberDataError(f"Invalid phone for member '{name}'")

    return Member(name, email, phone)

# To process a list of raw member data and handle errors
def process_members(raw_members):
    processed_members = []
    for data in raw_members:
        try:
            print(f"Processing member: {data.get('name', 'Unknown')}...")
            member = process_member(data)
            processed_members.append(member)
            print("Validation Successful.")

        except InvalidMemberDataError as error:
            print(f"Error: {error}. Skipping.")

        except (KeyError, TypeError) as error:
            print(f"Error: Invalid member data ({error}). Skipping.")

    print(f"Summary: {len(processed_members)} members "
        f"processed successfully.")
    return processed_members

# To filter members by email domain
def filter_members_by_email(members, domain):
    return list(
        filter(
            lambda member: member.email.endswith(domain),
            members
        )
    )