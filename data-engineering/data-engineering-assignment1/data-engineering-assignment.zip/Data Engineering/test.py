from my_processor.core import Member

member = Member(
    "Garima Verma",
    "garima@gmail.com",
    "6122131322"
)

print(f"Member Details: \n{member}")
