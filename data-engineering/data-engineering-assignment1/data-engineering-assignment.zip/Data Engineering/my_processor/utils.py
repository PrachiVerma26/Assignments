# helper functions for data processing
import re


def clean_name(name):
    return name.strip()

def validate_email(email):
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    return re.match(pattern, email) is not None

def validate_phone(phone):
    pattern = r"^\d{10}$"
    return re.match(pattern, phone) is not None