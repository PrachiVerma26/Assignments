from setuptools import setup, find_packages

# This setup.py file is used to package and distribute the data_processor_task project.
setup(
    name="data_processor_task",
    version="1.0.0",
    description="A core Python training assignment project",
    packages=find_packages(),
)