# This is the starting point of the application. 
# It processes a list of raw member data, validates it, and filters members based on their email domain.

from my_processor.core import process_members, filter_members_by_email

raw_members = [
    {
        "name": "Ram Verma",
        "email": "ramverma12@gmail.com",
        "phone": "4560101232"
    },
    {
        "name": "Shreya Rathore",
        "email": "shreyarathore@gmail.com",
        "phone": "5550102242"
    },
    {
        "name": "HimanshiTanwar",
        "email": "himanshi@yahoo,com",
        "phone": "555033323121"
    }
]

def main():
    members = process_members(raw_members)
    print("\nMembers with @gmail.com:")
    filtered_members = filter_members_by_email(members, "@gmail.com")
    for member in filtered_members:
        print(member)

if __name__ == "__main__":
    main()